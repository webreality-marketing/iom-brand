(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.mc_level4_jersey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3BIQABgMAEgLQATALAZAAQAiAAAAgWQgBgJgFgGQgGgFgOgFIgOgFQgqgLAAgjQAAgVAPgLQAPgMAbAAQAaAAAUAHQAAANgDAKQgUgIgWAAQgeAAgBAWQAAARAbAIIAOAFQAqAMAAAgQAAAVgQANQgQANgdAAQgeAAgUgLg");
	this.shape.setTransform(321.75,30.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AglA3IAAibQALgEAQAAIAAAwIAwAAIgCAXIguAAIAABWQAAAcAYAAQANAAALgGIgDAYQgNAGgOAAQgtAAAAgyg");
	this.shape_1.setTransform(309.9,28.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAjBRIAAhiQABgpgjAAQgTAAgRASIAAB5IgcAAIAAidIAaAAIACAYQAQgcAeAAQAaAAAOAPQANAOgBAZIAABrg");
	this.shape_2.setTransform(295.25,30.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgvA9QgUgWAAgnQAAglARgVQATgYAiAAQAgAAARAUQAQASAAAhQAAANgCAIIhoAAQAFAyAvAAQAZAAAXgNQgBAPgDAKQgWALgYAAQgnAAgUgWgAAngMQAAgwglAAQgkAAgEAwIBNAAIAAAAg");
	this.shape_3.setTransform(278.325,30.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgwBeQgRgVAAgoQgBhUBNAAQAPAAANACIAAg9QAMgEAQAAIAADhIgaAAIgBgVQgOAZgcAAQgdAAgRgVgAgmAgQAAA8ArAAQATAAAPgQIAAhkQgMgEgPAAQgyAAAAA8g");
	this.shape_4.setTransform(261.25,27.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgNByIAAieIAbAAIAACegAgLhSQgGgFAAgHQAAgJAGgFQAEgFAHAAQAIAAAFAFQAFAFAAAJQAAAHgFAFQgFAFgIABQgGAAgFgGg");
	this.shape_5.setTransform(249.425,26.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag3BIQABgMAEgLQATALAZAAQAiAAgBgWQAAgJgFgGQgGgFgPgFIgNgFQgqgLAAgjQAAgVAPgLQAPgMAbAAQAaAAAVAHQgBANgEAKQgUgIgUAAQggAAAAAWQAAARAbAIIAPAFQAoAMAAAgQAAAVgPANQgRANgcAAQgeAAgUgLg");
	this.shape_6.setTransform(238.75,30.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgvA9QgUgWAAgnQAAglARgVQATgYAiAAQAgAAARAUQAQASAAAhQAAANgCAIIhoAAQAFAyAvAAQAZAAAXgNQgBAPgDAKQgWALgYAAQgnAAgUgWgAAngMQAAgwglAAQgkAAgEAwIBNAAIAAAAg");
	this.shape_7.setTransform(223.525,30.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgqBRIAAieIAaAAIACAYQANgbAaAAQAJAAAJACQAAAOgDALQgJgCgKAAQgWAAgNAPIAAB5g");
	this.shape_8.setTransform(210.975,30.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAkBRIAAhiQAAgpgiAAQgUAAgRASIAAB5IgbAAIAAidIAZAAIACAYQAQgcAeAAQAaAAANAPQANAOABAZIAABrg");
	this.shape_9.setTransform(188.85,30.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgvBHQgPgNAAgXQABgbATgMQAVgPAxgDIAHAAIAAgGQAAgRgIgHQgIgIgSAAQgcAAgZANQABgNACgLQAWgLAgAAQA5AAAAA0IAABtIgZAAIgCgWQgOAagfAAQgYAAgNgMgAAegCQgmACgOAJQgNAIAAAQQAAANAIAHQAIAIAOAAQAZAAAPgUIAAgrg");
	this.shape_10.setTransform(171.7,30.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("ABXBwIgFhfIgEhXQgPAvgVA2IggBRIgUAAIghhXQgWg3gMgnQAAAhgEA6IgGBaIgbAAIAPjaQAOgFAUAAIBBC4IBBizQAMgFAYAAIAODfg");
	this.shape_11.setTransform(150.375,27.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgpBxIAAirQAAg2A3AAQAQAAAMADQAAAJgCAPQgMgEgMAAQgQAAgGAHQgIAIAAARIAAAMIA1AAIgDAXIgyAAIAACHg");
	this.shape_12.setTransform(125.65,27);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ag1A9QgTgWAAgnQABgmASgWQATgWAiAAQAiAAATAWQAUAWgBAmQABAngUAWQgTAWgiAAQgiAAgTgWgAgrAAQAAA8ArAAQAsAAAAg8QAAg8gsAAQgrAAAAA8g");
	this.shape_13.setTransform(110.6,30.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgvA9QgUgWAAgnQAAglARgVQATgYAiAAQAgAAARAUQAQASAAAhQAAANgCAIIhoAAQAFAyAvAAQAZAAAXgNQgBAPgDAKQgWALgYAAQgnAAgUgWgAAngMQAAgwglAAQgkAAgEAwIBNAAIAAAAg");
	this.shape_14.setTransform(87.025,30.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgdBIIAAi2QALgEAQAAIAAC4QAAAVASAAQAIAAAHgDQgBALgDAMQgJAEgLAAQgkAAAAgrg");
	this.shape_15.setTransform(75.4,27.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag2BIQAAgMADgLQAUALAZAAQAiAAAAgWQAAgJgHgGQgFgFgOgFIgOgFQgqgLAAgjQAAgVAPgLQAPgMAbAAQAaAAAUAHQgBANgCAKQgVgIgVAAQgeAAAAAWQAAARAaAIIAOAFQApAMABAgQAAAVgQANQgRANgcAAQgeAAgTgLg");
	this.shape_16.setTransform(63.2,30.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgNBwIAAjaQANgFAOAAIAADfg");
	this.shape_17.setTransform(51.975,27.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgqBRIAAieIAaAAIACAYQANgbAaAAQAJAAAJACQAAAOgDALQgJgCgKAAQgWAAgNAPIAAB5g");
	this.shape_18.setTransform(36.325,30.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("Ag1A9QgSgWgBgnQAAgmATgWQATgWAiAAQAjAAASAWQATAWAAAmQAAAngTAWQgTAWgiAAQghAAgUgWgAgrAAQAAA8ArAAQAsAAAAg8QAAg8gsAAQgrAAAAA8g");
	this.shape_19.setTransform(21.2,30.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgpBxIAAirQAAg2A3AAQAQAAAMADQAAAJgCAPQgNgEgLAAQgQAAgHAHQgGAIgBARIAAAMIA1AAIgDAXIgyAAIAACHg");
	this.shape_20.setTransform(8.6,27);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_level4_jersey, new cjs.Rectangle(0,0,330.9,50.2), null);


(lib.SantanderInternationalpos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EC0000").s().p("AM7GsQgVgZAAgtQAAgvAXgZQAYgZAuAAQAgABAbAJIAACxIgXAAIgBgPQgUATgbgBQgmAAgWgXgANPEvQgQATAAAkQAAAiAOAUQAPATAdAAQAaAAATgSIAAh+QgRgDgSAAQgiAAgSATgAG1GpQgWgZAAgqQAAgtAXgaQAXgaApAAQAqAAAWAbQAVAZAAAqQAAAtgWAZQgYAagpAAQgpAAgWgagAHIEwQgQASAAAiQAAAjAQAUQAPASAfABQAdgBAQgTQAPgUAAghQAAgjgPgTQgQgTgdAAQgeAAgQAUgADnGLIAAi9QAMgEAMAAIAABBIBAAAQgBAOgCAIIg9AAIAABoQAAAmAigBQAPAAAQgFIgEAVQgOAGgRgBQg3AAABg4gAA2GsQgWgZABgtQAAgvAWgZQAYgZAvAAQAgABAbAJIAACxIgXAAIgBgPQgVATgagBQgnAAgVgXgABKEvQgQATAAAkQAAAiAOAUQAPATAdAAQAaAAASgSIAAh+QgQgDgSAAQgjAAgRATgAm6GqQgWgZgBgtQABgqASgZQAWgbAogBQAmAAAUAZQASAVAAAkQAAANgBAJIiDAAQADAgAQAQQARARAdAAQAigBAZgPIgDAYQgXANghAAQgrAAgYgZgAmoErQgOAQgCAcIBrAAIAAgCQAAgagMgQQgOgQgaAAQgZAAgOAQgAo3GLIAAi9QALgEAOAAIAABBIA/AAQgBANgBAJIg9AAIAABoQgBAmAjgBQAPAAAPgFIgDAVQgPAGgRgBQg2AAAAg4gAPuHAIAAjyQAPgEAKAAIAAD2gALpHAIAAhzQAAgagLgLQgNgMgfAAQgVAAgUAEIAACgIgZAAIAAixQAlgJAdgBQArAAATASQASAQAAAiIAAB3gAFiHAIAAi2IAYAAIAAC2gAgcHAIAAhzQAAgagLgLQgMgMggAAQgTAAgWAEIAACgIgYAAIAAixQAkgJAegBQArAAATASQASAQAAAiIAAB3gAkOHAIAAixQAMgEAQgCQAQgDAPAAQAUAAAKACQAAANgCAIQgLgBgQAAQgQAAgTADIAAChgAp8HAIAAhzQABgagMgLQgNgMgfAAQgUAAgVAEIAACgIgZAAIAAixQAlgJAdgBQAsAAATASQARAQAAAiIAAB3gAtJHAIAAjyQAPgEAJAAIAAD2gAFjDpQgGgFAAgHQAAgHAGgFQAEgEAHAAQAHAAAEAEQAFAFABAHQgBAHgFAFQgEAFgHAAQgHAAgEgFgA2KAeQhRgrAAg+QAAgsArgkQArgkBHgTQgCAjASAfIBWCUQAKARAEATIADgGQAQgcAAgfQAAgggQgcIhFh4QgQgcAAgfQAAghAQgcIAEgGQAEATAJARIBoC0QAKARAEATIAEgGQAQgcAAgfQAAgggQgdIhGh4QgQgbAAghQAAgfAQgcIAEgHQADATAKARIBXCXQAPAZABAdQBGATArAkQAsAkAAAsQAAA+hRArQhRAshzAAQhyAAhRgsgAtLAtQACgbAJgZQAUAJAbAFQAZAFAWABQAlAAATgMQAUgLAAgXQAAgVgQgPQgOgMgngRIgagLQgogSgUgVQgWgaAAgnQAAguAfgYQAggbA+AAQA0AAArAPQgCAcgJAYQgTgIgZgDQgVgEgTAAQgiAAgRANQgQALAAAVQAAATAPAOQANAMAdANIAcAMQAyAVAWAYQAVAZAAAmQAAAtghAbQgjAbhBAAQg/AAgsgTgARHAZQgjgjAAhEQAAg/AdgkQAhgoBAAAQA7AAAfAkQAbAfABA0QgBAVgDAXIi2AAQAFAjAVARQAVAQAmAAQAwAAArgTQgEAcgFAXQgjAQgwAAQhHAAgkglgATehlQgBghgQgRQgQgSgdAAQg8AAgHBEICBAAIAAAAgAMgAaQgegjAAhAQAAhGAkgkQAlgmBHAAQAWAAAUAEIAAhVQAXgIAiAAIAAFqIg0AAIgDghQgMAUgRAJQgSAKgcAAQg0ABgfglgANQiPQgVAYAAAuQABApAQAXQATAZAkAAQAgAAAZgTIAAigQgYgFgVAAQgqAAgVAZgADdAaQgggjAAhAQAAhGAkgkQAlgmBHAAQA5AAApAPIAAECIg0AAIgDgfQgXAlgyAAQg0ABgeglgAEMiPQgVAZAAAtQAAApARAXQASAZAlAAQAfAAAZgSIAAiiQgTgEgXAAQgqAAgXAZgAAZgZIAAkQQAZgJAfAAIAABiIBaAAQgBAbgDAWIhWAAIAAB/QABAuArAAQAYAAAVgIQgDAcgEAUQgUAIgcAAQhaAAAAhXgAoXAaQgggjAAhAQAAhGAkgkQAlgmBIAAQA4AAAqAPIAAECIg1AAIgCgfQgYAlgxAAQg1ABgeglgAnniPQgWAZABAtQAAApAQAXQATAZAlAAQAeAAAZgSIAAiiQgTgEgWAAQgsAAgVAZgAVIA4IAAkCQATgGAcgFQAbgEAYAAQAhABARABIgBAbQgCAPgCAHQgTgCgZAAQgUAAgVAEIAADcgAKaA4IAAijQAAghgNgNQgQgPgpAAQgUAAgZAFIAADbIg5AAIAAkCQAcgGAbgFQAcgEAVAAQBEAAAfAbQAbAYAAAxIAACtgAhZA4IAAijQAAghgNgNQgRgPgpAAQgTAAgaAFIAADbIg5AAIAAkCQAcgGAbgFQAcgEAVAAQBFAAAeAbQAbAYAAAxIAACtg");
	this.shape.setTransform(150,45.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.SantanderInternationalpos, new cjs.Rectangle(0,0,300,90.3), null);


(lib.primary_cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgfAAQABgQAHgJQAJgLAPABQAPgBAIAKQAIAHgBAOIgBAMIgqAAQABAJAFADQAFAEAIgBQALAAALgEIgCAOQgKAEgLABQglAAAAglgAANgFQAAgRgMAAQgMAAgCARIAaAAIAAAAg");
	this.shape.setTransform(110.65,18.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTAkIAAhFIAQAAIABAKQAFgMAKAAIAHABQAAAJgBAHIgIgBQgIAAgEAEIAAAzg");
	this.shape_1.setTransform(104.9,18.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_2.setTransform(98.125,18.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAhAkIAAgqQAAgOgMAAQgHAAgFAFIAAAFIAAAuIgRAAIAAgqQAAgOgLAAQgHAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNANAAQAPAAAFANQAHgNAOAAQAXAAAAAZIAAAug");
	this.shape_3.setTransform(88.425,18.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAXIAAhCQAIgCAKAAIAAAVIATAAIgCAPIgRAAIAAAeQAAALAIAAQAFAAAFgCIgCAOQgGACgHABQgVAAAAgYg");
	this.shape_4.setTransform(76.975,17.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgYAdQgFgGAAgMIAAguIASAAIAAArQAAAOALAAQAGAAAGgGIAAgzIASAAIAABFIgRAAIgBgLQgGANgMAAQgMAAgGgHg");
	this.shape_5.setTransform(70.425,18.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_6.setTransform(62.775,18.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWAqQgJgJABgSQgBgkAkAAIAJAAIAAgaQAJgCAJAAIAABiIgRAAIgBgJQgGAKgLABQgMAAgHgJgAgMAPQAAAWAOgBQAHAAAFgEIAAgnIgKAAQgQAAAAAWg");
	this.shape_7.setTransform(51.65,16.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAMAkIAAgqQAAgOgMAAQgFAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNAMAAQAMAAAFAHQAGAGAAAMIAAAug");
	this.shape_8.setTransform(44.225,18.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIAzIAAhFIARAAIAABFgAgGggQgEgDAAgFQAAgEAEgDQADgDADAAQAEAAADADQADADABAEQgBAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_9.setTransform(38.6,16.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbAwIAAhgIA3AAQAAAIgBAIIgkAAIAAAZIAiAAQAAAHgCAIIggAAIAAAog");
	this.shape_10.setTransform(33.625,16.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgfAAQABgQAHgJQAJgLAPABQAPgBAIAKQAIAHgBAOIgBAMIgqAAQABAJAFADQAFAEAIgBQALAAALgEIgCAOQgKAEgLABQglAAAAglgAANgFQAAgRgMAAQgMAAgCARIAaAAIAAAAg");
	this.shape_11.setTransform(110.65,18.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgTAkIAAhFIAQAAIABAKQAFgMAKAAIAHABQAAAJgBAHIgIgBQgIAAgEAEIAAAzg");
	this.shape_12.setTransform(104.9,18.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_13.setTransform(98.125,18.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAhAkIAAgqQAAgOgMAAQgHAAgFAFIAAAFIAAAuIgRAAIAAgqQAAgOgLAAQgHAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNANAAQAPAAAFANQAHgNAOAAQAXAAAAAZIAAAug");
	this.shape_14.setTransform(88.425,18.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgSAXIAAhCQAIgCAKAAIAAAVIATAAIgCAPIgRAAIAAAeQAAALAIAAQAFAAAFgCIgCAOQgGACgHABQgVAAAAgYg");
	this.shape_15.setTransform(76.975,17.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgYAdQgFgGAAgMIAAguIASAAIAAArQAAAOALAAQAGAAAGgGIAAgzIASAAIAABFIgRAAIgBgLQgGANgMAAQgMAAgGgHg");
	this.shape_16.setTransform(70.425,18.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_17.setTransform(62.775,18.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgWAqQgJgJABgSQgBgkAkAAIAJAAIAAgaQAJgCAJAAIAABiIgRAAIgBgJQgGAKgLABQgMAAgHgJgAgMAPQAAAWAOgBQAHAAAFgEIAAgnIgKAAQgQAAAAAWg");
	this.shape_18.setTransform(51.65,16.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAMAkIAAgqQAAgOgMAAQgFAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNAMAAQAMAAAFAHQAGAGAAAMIAAAug");
	this.shape_19.setTransform(44.225,18.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgIAzIAAhFIARAAIAABFgAgGggQgEgDAAgFQAAgEAEgDQADgDADAAQAEAAADADQADADABAEQgBAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_20.setTransform(38.6,16.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgbAwIAAhgIA3AAQAAAIgBAIIgkAAIAAAZIAiAAQAAAHgCAIIggAAIAAAog");
	this.shape_21.setTransform(33.625,16.95);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgfAAQABgQAHgJQAJgLAPABQAPgBAIAKQAIAHgBAOIgBAMIgqAAQABAJAFADQAFAEAIgBQALAAALgEIgCAOQgKAEgLABQglAAAAglgAANgFQAAgRgMAAQgMAAgCARIAaAAIAAAAg");
	this.shape_22.setTransform(110.65,18.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgTAkIAAhFIAQAAIABAKQAFgMAKAAIAHABQAAAJgBAHIgIgBQgIAAgEAEIAAAzg");
	this.shape_23.setTransform(104.9,18.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_24.setTransform(98.125,18.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAhAkIAAgqQAAgOgMAAQgHAAgFAFIAAAFIAAAuIgRAAIAAgqQAAgOgLAAQgHAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNANAAQAPAAAFANQAHgNAOAAQAXAAAAAZIAAAug");
	this.shape_25.setTransform(88.425,18.225);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgSAXIAAhCQAIgCAKAAIAAAVIATAAIgCAPIgRAAIAAAeQAAALAIAAQAFAAAFgCIgCAOQgGACgHABQgVAAAAgYg");
	this.shape_26.setTransform(76.975,17.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgYAdQgFgGAAgMIAAguIASAAIAAArQAAAOALAAQAGAAAGgGIAAgzIASAAIAABFIgRAAIgBgLQgGANgMAAQgMAAgGgHg");
	this.shape_27.setTransform(70.425,18.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_28.setTransform(62.775,18.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgWAqQgJgJABgSQgBgkAkAAIAJAAIAAgaQAJgCAJAAIAABiIgRAAIgBgJQgGAKgLABQgMAAgHgJgAgMAPQAAAWAOgBQAHAAAFgEIAAgnIgKAAQgQAAAAAWg");
	this.shape_29.setTransform(51.65,16.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAMAkIAAgqQAAgOgMAAQgFAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNAMAAQAMAAAFAHQAGAGAAAMIAAAug");
	this.shape_30.setTransform(44.225,18.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgIAzIAAhFIARAAIAABFgAgGggQgEgDAAgFQAAgEAEgDQADgDADAAQAEAAADADQADADABAEQgBAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_31.setTransform(38.6,16.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgbAwIAAhgIA3AAQAAAIgBAIIgkAAIAAAZIAiAAQAAAHgCAIIggAAIAAAog");
	this.shape_32.setTransform(33.625,16.95);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EC0000").s().p("AgfAAQABgQAHgJQAJgLAPABQAPgBAIAKQAIAHgBAOIgBAMIgqAAQABAJAFADQAFAEAIgBQALAAALgEIgCAOQgKAEgLABQglAAAAglgAANgFQAAgRgMAAQgMAAgCARIAaAAIAAAAg");
	this.shape_33.setTransform(110.65,18.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#EC0000").s().p("AgTAkIAAhFIAQAAIABAKQAFgMAKAAIAHABQAAAJgBAHIgIgBQgIAAgEAEIAAAzg");
	this.shape_34.setTransform(104.9,18.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#EC0000").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_35.setTransform(98.125,18.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#EC0000").s().p("AAhAkIAAgqQAAgOgMAAQgHAAgFAFIAAAFIAAAuIgRAAIAAgqQAAgOgLAAQgHAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNANAAQAPAAAFANQAHgNAOAAQAXAAAAAZIAAAug");
	this.shape_36.setTransform(88.425,18.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#EC0000").s().p("AgSAXIAAhCQAIgCAKAAIAAAVIATAAIgCAPIgRAAIAAAeQAAALAIAAQAFAAAFgCIgCAOQgGACgHABQgVAAAAgYg");
	this.shape_37.setTransform(76.975,17.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#EC0000").s().p("AgYAdQgFgGAAgMIAAguIASAAIAAArQAAAOALAAQAGAAAGgGIAAgzIASAAIAABFIgRAAIgBgLQgGANgMAAQgMAAgGgHg");
	this.shape_38.setTransform(70.425,18.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#EC0000").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_39.setTransform(62.775,18.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#EC0000").s().p("AgWAqQgJgJABgSQgBgkAkAAIAJAAIAAgaQAJgCAJAAIAABiIgRAAIgBgJQgGAKgLABQgMAAgHgJgAgMAPQAAAWAOgBQAHAAAFgEIAAgnIgKAAQgQAAAAAWg");
	this.shape_40.setTransform(51.65,16.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EC0000").s().p("AAMAkIAAgqQAAgOgMAAQgFAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNAMAAQAMAAAFAHQAGAGAAAMIAAAug");
	this.shape_41.setTransform(44.225,18.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EC0000").s().p("AgIAzIAAhFIARAAIAABFgAgGggQgEgDAAgFQAAgEAEgDQADgDADAAQAEAAADADQADADABAEQgBAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_42.setTransform(38.6,16.675);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#EC0000").s().p("AgbAwIAAhgIA3AAQAAAIgBAIIgkAAIAAAZIAiAAQAAAHgCAIIggAAIAAAog");
	this.shape_43.setTransform(33.625,16.95);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#EC0000").s().p("AgfAAQABgQAHgJQAJgLAPABQAPgBAIAKQAIAHgBAOIgBAMIgqAAQABAJAFADQAFAEAIgBQALAAALgEIgCAOQgKAEgLABQglAAAAglgAANgFQAAgRgMAAQgMAAgCARIAaAAIAAAAg");
	this.shape_44.setTransform(110.65,18.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#EC0000").s().p("AgTAkIAAhFIAQAAIABAKQAFgMAKAAIAHABQAAAJgBAHIgIgBQgIAAgEAEIAAAzg");
	this.shape_45.setTransform(104.9,18.225);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#EC0000").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_46.setTransform(98.125,18.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#EC0000").s().p("AAhAkIAAgqQAAgOgMAAQgHAAgFAFIAAAFIAAAuIgRAAIAAgqQAAgOgLAAQgHAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNANAAQAPAAAFANQAHgNAOAAQAXAAAAAZIAAAug");
	this.shape_47.setTransform(88.425,18.225);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#EC0000").s().p("AgSAXIAAhCQAIgCAKAAIAAAVIATAAIgCAPIgRAAIAAAeQAAALAIAAQAFAAAFgCIgCAOQgGACgHABQgVAAAAgYg");
	this.shape_48.setTransform(76.975,17.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#EC0000").s().p("AgYAdQgFgGAAgMIAAguIASAAIAAArQAAAOALAAQAGAAAGgGIAAgzIASAAIAABFIgRAAIgBgLQgGANgMAAQgMAAgGgHg");
	this.shape_49.setTransform(70.425,18.375);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#EC0000").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_50.setTransform(62.775,18.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#EC0000").s().p("AgWAqQgJgJABgSQgBgkAkAAIAJAAIAAgaQAJgCAJAAIAABiIgRAAIgBgJQgGAKgLABQgMAAgHgJgAgMAPQAAAWAOgBQAHAAAFgEIAAgnIgKAAQgQAAAAAWg");
	this.shape_51.setTransform(51.65,16.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#EC0000").s().p("AAMAkIAAgqQAAgOgMAAQgFAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNAMAAQAMAAAFAHQAGAGAAAMIAAAug");
	this.shape_52.setTransform(44.225,18.225);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#EC0000").s().p("AgIAzIAAhFIARAAIAABFgAgGggQgEgDAAgFQAAgEAEgDQADgDADAAQAEAAADADQADADABAEQgBAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_53.setTransform(38.6,16.675);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#EC0000").s().p("AgbAwIAAhgIA3AAQAAAIgBAIIgkAAIAAAZIAiAAQAAAHgCAIIggAAIAAAog");
	this.shape_54.setTransform(33.625,16.95);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#EC0000").s().p("AgfAAQABgQAHgJQAJgLAPABQAPgBAIAKQAIAHgBAOIgBAMIgqAAQABAJAFADQAFAEAIgBQALAAALgEIgCAOQgKAEgLABQglAAAAglgAANgFQAAgRgMAAQgMAAgCARIAaAAIAAAAg");
	this.shape_55.setTransform(110.65,18.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#EC0000").s().p("AgTAkIAAhFIAQAAIABAKQAFgMAKAAIAHABQAAAJgBAHIgIgBQgIAAgEAEIAAAzg");
	this.shape_56.setTransform(104.9,18.225);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#EC0000").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_57.setTransform(98.125,18.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#EC0000").s().p("AAhAkIAAgqQAAgOgMAAQgHAAgFAFIAAAFIAAAuIgRAAIAAgqQAAgOgLAAQgHAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNANAAQAPAAAFANQAHgNAOAAQAXAAAAAZIAAAug");
	this.shape_58.setTransform(88.425,18.225);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#EC0000").s().p("AgSAXIAAhCQAIgCAKAAIAAAVIATAAIgCAPIgRAAIAAAeQAAALAIAAQAFAAAFgCIgCAOQgGACgHABQgVAAAAgYg");
	this.shape_59.setTransform(76.975,17.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#EC0000").s().p("AgYAdQgFgGAAgMIAAguIASAAIAAArQAAAOALAAQAGAAAGgGIAAgzIASAAIAABFIgRAAIgBgLQgGANgMAAQgMAAgGgHg");
	this.shape_60.setTransform(70.425,18.375);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#EC0000").s().p("AgYAbQgJgJAAgSQAAgQAJgKQAJgJAPAAQAQAAAJAJQAJAKAAAQQAAARgJAKQgJAKgQAAQgPAAgJgKgAgOAAQAAAWAOAAQAPAAAAgWQAAgVgPAAQgOAAAAAVg");
	this.shape_61.setTransform(62.775,18.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#EC0000").s().p("AgWAqQgJgJABgSQgBgkAkAAIAJAAIAAgaQAJgCAJAAIAABiIgRAAIgBgJQgGAKgLABQgMAAgHgJgAgMAPQAAAWAOgBQAHAAAFgEIAAgnIgKAAQgQAAAAAWg");
	this.shape_62.setTransform(51.65,16.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#EC0000").s().p("AAMAkIAAgqQAAgOgMAAQgFAAgGAFIAAAzIgSAAIAAhFIAQAAIACALQAGgNAMAAQAMAAAFAHQAGAGAAAMIAAAug");
	this.shape_63.setTransform(44.225,18.225);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#EC0000").s().p("AgIAzIAAhFIARAAIAABFgAgGggQgEgDAAgFQAAgEAEgDQADgDADAAQAEAAADADQADADABAEQgBAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_64.setTransform(38.6,16.675);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#EC0000").s().p("AgbAwIAAhgIA3AAQAAAIgBAIIgkAAIAAAZIAiAAQAAAHgCAIIggAAIAAAog");
	this.shape_65.setTransform(33.625,16.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33}]},1).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(2));

	// Layer_1
	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#EC0000").ss(1,1,1).p("AolipIRLAAQBHAAAxAyQAyAyAABFQAABGgyAyQgxAyhHAAIxLAAQhHAAgygyQgxgyAAhGQAAhFAxgyQAygyBHAAg");
	this.shape_66.setTransform(72,17);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#EC0000").s().p("AolCqQhHAAgygyQgxgyAAhGQAAhFAxgyQAygyBHAAIRLAAQBGAAAyAyQAyAyAABFQAABGgyAyQgyAyhGAAg");
	this.shape_67.setTransform(72,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_67},{t:this.shape_66}]}).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67},{t:this.shape_66}]},1).to({state:[{t:this.shape_67},{t:this.shape_66}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,146,36);


(lib.mc_level1_finalIOM = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_299 = function() {
		if (!this.looped) this.looped = 1;
		if (this.looped++ == 1) this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(299).call(this.frame_299).wait(1));

	// s
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EC0000").s().p("Ag2BKQAAgMAEgMQAUAMAXAAQAiAAAAgXQAAgJgGgGQgGgFgOgFIgMgGQgVgIgJgIQgMgMAAgTQAAgVAOgMQAQgMAbAAQAaAAAUAIQgBANgDAKQgVgIgTAAQggAAAAAVQAAARAaAKIAOAFQAVAIAKAJQAKALAAARQAAAVgPANQgRAOgcAAQgdAAgUgLg");
	this.shape.setTransform(194.575,103.475);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(47).to({_off:false},0).wait(253));

	// e
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EC0000").s().p("AgwA+QgTgWAAgoQAAglARgWQATgZAiAAQAgAAARAUQAQATAAAiIgCAUIhoAAQAEA1AwAAQAaAAAWgOQgBAPgDALQgSALgdAAQgmAAgVgXgAAngNQAAgwglAAQgkAAgEAwIBNAAIAAAAg");
	this.shape_1.setTransform(179.775,103.475);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(46).to({_off:false},0).wait(254));

	// g
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EC0000").s().p("Ag1BtQAAgMACgMQAVAKAWAAQAvAAAAgwIAAgWQgNAZgcAAQgeAAgQgUQgSgWAAgoQAAhWBNAAQAfAAAZAJIAACZQAABLhKAAQgZAAgVgKgAgmghQAAA8ArAAQAUAAAOgQIAAhmQgMgEgPAAQgyAAAAA+g");
	this.shape_2.setTransform(163.075,106.925);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(45).to({_off:false},0).wait(255));

	// a
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EC0000").s().p("AgwBAQgRgVAAgqQAAhVBMAAQAeAAAZAJIAACcIgaAAIgBgWQgPAagbAAQgdAAgQgVgAglAAQAAA+ApAAQAUAAAOgQIAAhnQgNgEgPAAQgvAAAAA9g");
	this.shape_3.setTransform(146.575,103.475);
	this.shape_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(44).to({_off:false},0).wait(256));

	// g
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EC0000").s().p("Ag1BtQAAgMACgMQAVAKAWAAQAvAAAAgwIAAgWQgNAZgcAAQgeAAgQgUQgSgWAAgoQAAhWBNAAQAfAAAZAJIAACZQAABLhKAAQgZAAgVgKgAgmghQAAA8ArAAQAUAAAOgQIAAhmQgMgEgPAAQgyAAAAA+g");
	this.shape_4.setTransform(129.925,106.925);
	this.shape_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(43).to({_off:false},0).wait(257));

	// t
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EC0000").s().p("AgmA5IAAifQAMgEAQAAIAAAxIAxAAIgDAXIguAAIAABYQAAAdAZAAQAMAAALgGIgDAYQgLAGgQAAQguAAAAgyg");
	this.shape_5.setTransform(117.275,101.25);
	this.shape_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(42).to({_off:false},0).wait(258));

	// r
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EC0000").s().p("AgqBSIAAibQAZgIAbAAQATAAAOACQAAAQgDAJQgLgDgTAAQgKAAgOACIAACJg");
	this.shape_6.setTransform(106.7,103.325);
	this.shape_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(41).to({_off:false},0).wait(259));

	// o
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EC0000").s().p("Ag1A+QgTgWAAgoQAAgnATgWQATgXAiAAQAjAAATAXQATAWAAAnQAAAogTAWQgTAXgjAAQgiAAgTgXgAgrAAQAAA+ArAAQAsAAAAg+QAAg9gsAAQgrAAAAA9g");
	this.shape_7.setTransform(92.025,103.475);
	this.shape_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(40).to({_off:false},0).wait(260));

	// m
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EC0000").s().p("ABVBTIAAhoQAAgTgJgJQgJgKgUAAQgTAAgSAKQAEALAAAOIAABrIgbAAIAAhoQAAgUgJgJQgJgJgVAAQgPAAgRAEIAACKIgcAAIAAibQAhgKAcAAQAjAAAQAQQAVgQAhAAQA7AAAAA4IAABtg");
	this.shape_8.setTransform(70.575,103.275);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(39).to({_off:false},0).wait(261));

	// d
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EC0000").s().p("AgwBgQgSgWAAgpQAAhVBNAAQAQAAAMACIAAg+QAMgEAQAAIAADlIgaAAIgBgWQgOAagcAAQgeAAgQgVgAgmAhQAAA9ArAAQAUAAAOgQIAAhnQgMgEgPAAQgyAAAAA+g");
	this.shape_9.setTransform(41.975,100.275);
	this.shape_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(38).to({_off:false},0).wait(262));

	// n
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EC0000").s().p("AAkBTIAAhoQgBgUgIgJQgKgJgUAAQgPAAgQAEIAACKIgcAAIAAibQAggKAcAAQBCAAAAA6IAABrg");
	this.shape_10.setTransform(25.95,103.275);
	this.shape_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(37).to({_off:false},0).wait(263));

	// a
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#EC0000").s().p("AgwBAQgRgVAAgqQAAhVBMAAQAeAAAZAJIAACcIgaAAIgBgWQgPAagbAAQgdAAgQgVgAglAAQAAA+ApAAQAUAAAOgQIAAhnQgNgEgPAAQgvAAAAA9g");
	this.shape_11.setTransform(8.775,103.475);
	this.shape_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(36).to({_off:false},0).wait(264));

	// s
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EC0000").s().p("Ag2BKQAAgMAEgMQAUAMAXAAQAiAAAAgXQAAgJgGgGQgGgFgOgFIgMgGQgVgIgJgIQgMgMAAgTQAAgVAOgMQAQgMAbAAQAaAAAUAIQgBANgDAKQgVgIgTAAQggAAAAAVQAAARAaAKIAOAFQAVAIAKAJQAKALAAARQAAAVgPANQgRAOgcAAQgdAAgUgLg");
	this.shape_12.setTransform(215.075,66.675);
	this.shape_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(33).to({_off:false},0).wait(267));

	// t
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EC0000").s().p("AgmA5IAAifQAMgEAQAAIAAAwIAxAAIgDAYIguAAIAABYQAAAdAZAAQAMAAALgGIgDAYQgLAGgQAAQguAAAAgyg");
	this.shape_13.setTransform(203.525,64.45);
	this.shape_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(32).to({_off:false},0).wait(268));

	// n
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EC0000").s().p("AAkBTIAAhoQgBgUgIgJQgJgJgVAAQgPAAgQAEIAACKIgcAAIAAibQAggKAcAAQBCAAAAA6IAABrg");
	this.shape_14.setTransform(189.55,66.475);
	this.shape_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(31).to({_off:false},0).wait(269));

	// u
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#EC0000").s().p("Ag/AZIAAhrIAcAAIAABoQAAAUAJAJQAJAJAVAAQAPAAAQgEIAAiKIAdAAIAACbQghAKgcAAQhCAAAAg6g");
	this.shape_15.setTransform(172.675,66.875);
	this.shape_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(30).to({_off:false},0).wait(270));

	// o
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EC0000").s().p("Ag1A+QgTgWAAgoQAAgnATgWQATgXAiAAQAjAAATAXQATAWAAAnQAAAogTAWQgTAXgjAAQgiAAgTgXgAgrAAQAAA+ArAAQAsAAAAg+QAAg9gsAAQgrAAAAA9g");
	this.shape_16.setTransform(156.125,66.675);
	this.shape_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(29).to({_off:false},0).wait(271));

	// c
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#EC0000").s().p("AgiBAQgVgWAAgqQAAgnATgWQATgXAlAAQAWAAAOAHQAAALgCAMQgPgGgSAAQgvAAAAA9QAAAcANAQQANARAWAAQATAAAPgJQgBANgDALQgNAIgUAAQgiAAgTgVg");
	this.shape_17.setTransform(141.275,66.675);
	this.shape_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(28).to({_off:false},0).wait(272));

	// c
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#EC0000").s().p("AgiBAQgVgWAAgqQAAgnATgWQATgXAlAAQAWAAAOAHQAAALgCAMQgPgGgSAAQgvAAAAA9QAAAcANAQQANARAWAAQATAAAPgJQgBANgDALQgNAIgUAAQgiAAgTgVg");
	this.shape_18.setTransform(128.125,66.675);
	this.shape_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(27).to({_off:false},0).wait(273));

	// a
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#EC0000").s().p("AgwBAQgRgVAAgqQAAhVBMAAQAeAAAZAJIAACcIgaAAIgBgWQgPAagbAAQgdAAgQgVgAglAAQAAA+ApAAQAUAAAOgQIAAhnQgNgEgPAAQgvAAAAA9g");
	this.shape_19.setTransform(112.775,66.675);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(26).to({_off:false},0).wait(274));

	// s
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#EC0000").s().p("Ag2BKQAAgMAEgMQAUAMAXAAQAiAAAAgXQAAgJgGgGQgGgFgOgFIgMgGQgVgIgJgIQgMgMAAgTQAAgVAOgMQAQgMAbAAQAaAAAUAIQgBANgDAKQgVgIgTAAQggAAAAAVQAAARAaAKIAOAFQAVAIAKAJQAKALAAARQAAAVgPANQgRAOgcAAQgdAAgUgLg");
	this.shape_20.setTransform(92.025,66.675);
	this.shape_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(25).to({_off:false},0).wait(275));

	// g
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#EC0000").s().p("Ag1BtQAAgMACgMQAVAKAWAAQAvAAAAgwIAAgWQgNAZgcAAQgeAAgQgUQgSgWAAgoQAAhWBNAAQAfAAAZAJIAACZQAABLhKAAQgZAAgVgKgAgmghQAAA8ArAAQAUAAAOgQIAAhmQgMgEgPAAQgyAAAAA+g");
	this.shape_21.setTransform(76.525,70.125);
	this.shape_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(24).to({_off:false},0).wait(276));

	// n
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#EC0000").s().p("AAjBTIAAhoQABgUgKgJQgJgJgTAAQgQAAgRAEIAACKIgcAAIAAibQAhgKAcAAQBBAAAAA6IAABrg");
	this.shape_22.setTransform(60.45,66.475);
	this.shape_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(23).to({_off:false},0).wait(277));

	// i
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EC0000").s().p("AgNB0IAAihIAbAAIAAChgAgMhTQgFgGAAgIQAAgIAFgFQAFgFAHAAQAHAAAGAFQAFAFAAAIQAAAIgFAGQgGAEgHAAQgHAAgFgEg");
	this.shape_23.setTransform(48.5,63.15);
	this.shape_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(22).to({_off:false},0).wait(278));

	// v
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#EC0000").s().p("AgNBRIg6ihIAeAAIAqCCIAriCIAcAAIg6Chg");
	this.shape_24.setTransform(37.875,66.675);
	this.shape_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(21).to({_off:false},0).wait(279));

	// a
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#EC0000").s().p("AgwBAQgRgVAAgqQAAhVBMAAQAeAAAZAJIAACcIgaAAIgBgWQgPAagbAAQgdAAgQgVgAglAAQAAA+ApAAQAUAAAOgQIAAhnQgNgEgPAAQgvAAAAA9g");
	this.shape_25.setTransform(22.025,66.675);
	this.shape_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(20).to({_off:false},0).wait(280));

	// s
	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#EC0000").s().p("Ag2BKQAAgMAEgMQAUAMAXAAQAiAAAAgXQAAgJgGgGQgGgFgOgFIgMgGQgVgIgJgIQgMgMAAgTQAAgVAOgMQAQgMAbAAQAaAAAUAIQgBANgDAKQgVgIgTAAQggAAAAAVQAAARAaAKIAOAFQAVAIAKAJQAKALAAARQAAAVgPANQgRAOgcAAQgdAAgUgLg");
	this.shape_26.setTransform(7.675,66.675);
	this.shape_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(19).to({_off:false},0).wait(281));

	// _
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EC0000").s().p("AgSAoQAGgiACgpQANgFAQAAQgFA2gOAag");
	this.shape_27.setTransform(234.6,38.65);
	this.shape_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(16).to({_off:false},0).wait(284));

	// s
	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#EC0000").s().p("Ag2BKQAAgMAEgMQAUAMAXAAQAiAAAAgXQAAgJgGgGQgGgFgOgFIgMgGQgVgIgJgIQgMgMAAgTQAAgVAOgMQAQgMAbAAQAaAAAUAIQgBANgDAKQgVgIgTAAQggAAAAAVQAAARAaAKIAOAFQAVAIAKAJQAKALAAARQAAAVgPANQgRAOgcAAQgdAAgUgLg");
	this.shape_28.setTransform(224.175,29.825);
	this.shape_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_28).wait(15).to({_off:false},0).wait(285));

	// t
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#EC0000").s().p("AgmA5IAAieQAMgFAQAAIAAAxIAxAAIgDAXIguAAIAABYQAAAdAZAAQAMAAALgGIgDAYQgLAGgQAAQguAAAAgyg");
	this.shape_29.setTransform(212.675,27.6);
	this.shape_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(14).to({_off:false},0).wait(286));

	// n
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#EC0000").s().p("AAkBTIAAhoQgBgUgIgJQgJgJgVAAQgPAAgQAEIAACKIgcAAIAAibQAggKAcAAQBCAAAAA6IAABrg");
	this.shape_30.setTransform(198.65,29.625);
	this.shape_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_30).wait(13).to({_off:false},0).wait(287));

	// u
	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#EC0000").s().p("Ag/AZIAAhrIAcAAIAABoQAAAUAJAJQAJAJAVAAQAPAAAQgEIAAiKIAdAAIAACbQghAKgcAAQhCAAAAg6g");
	this.shape_31.setTransform(181.775,30.025);
	this.shape_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(12).to({_off:false},0).wait(288));

	// o
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#EC0000").s().p("Ag1A+QgTgWAAgoQAAgnATgWQATgXAiAAQAjAAATAXQATAWAAAnQAAAogTAWQgTAXgjAAQgiAAgTgXgAgrAAQAAA+ArAAQAsAAAAg+QAAg9gsAAQgrAAAAA9g");
	this.shape_32.setTransform(165.225,29.825);
	this.shape_32._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(11).to({_off:false},0).wait(289));

	// c
	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EC0000").s().p("AgiBAQgVgWAAgqQAAgnATgWQATgXAlAAQAWAAAOAHQAAALgCAMQgPgGgSAAQgvAAAAA9QAAAcANAQQANARAWAAQATAAAPgJQgBANgDALQgNAIgUAAQgiAAgTgVg");
	this.shape_33.setTransform(150.375,29.825);
	this.shape_33._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(10).to({_off:false},0).wait(290));

	// c
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#EC0000").s().p("AgiBAQgVgWAAgqQAAgnATgWQATgXAlAAQAWAAAOAHQAAALgCAMQgPgGgSAAQgvAAAAA9QAAAcANAQQANARAWAAQATAAAPgJQgBANgDALQgNAIgUAAQgiAAgTgVg");
	this.shape_34.setTransform(137.225,29.825);
	this.shape_34._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(9).to({_off:false},0).wait(291));

	// a
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#EC0000").s().p("AgwBAQgRgVAAgqQAAhVBMAAQAeAAAZAJIAACcIgaAAIgBgWQgPAagbAAQgdAAgQgVgAglAAQAAA+ApAAQAUAAAOgQIAAhnQgNgEgPAAQgvAAAAA9g");
	this.shape_35.setTransform(121.875,29.825);
	this.shape_35._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(8).to({_off:false},0).wait(292));

	// g
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#EC0000").s().p("Ag1BtQAAgMACgMQAVAKAWAAQAvAAAAgwIAAgWQgNAZgcAAQgeAAgQgUQgSgWAAgoQAAhWBNAAQAfAAAZAJIAACZQAABLhKAAQgZAAgVgKgAgmghQAAA8ArAAQAUAAAOgQIAAhmQgMgEgPAAQgyAAAAA+g");
	this.shape_36.setTransform(98.925,33.275);
	this.shape_36._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_36).wait(7).to({_off:false},0).wait(293));

	// n
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#EC0000").s().p("AAkBTIAAhoQAAgUgJgJQgKgJgTAAQgQAAgRAEIAACKIgbAAIAAibQAggKAcAAQBBAAAAA6IAABrg");
	this.shape_37.setTransform(82.85,29.625);
	this.shape_37._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_37).wait(6).to({_off:false},0).wait(294));

	// i
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#EC0000").s().p("AgNB0IAAigIAbAAIAACggAgMhUQgFgFAAgHQAAgJAFgFQAFgFAHAAQAHAAAGAFQAFAFAAAJQAAAHgFAFQgGAGgHAAQgHAAgFgGg");
	this.shape_38.setTransform(70.9,26.3);
	this.shape_38._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_38).wait(5).to({_off:false},0).wait(295));

	// k
	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#EC0000").s().p("AAfBzIhBhVIAAgCIA8hKIAhAAIg/BKIBFBXgAhABzIAAjhQAMgEAQAAIAADlg");
	this.shape_39.setTransform(60.925,26.425);
	this.shape_39._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_39).wait(4).to({_off:false},0).wait(296));

	// n
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#EC0000").s().p("AAjBTIAAhoQAAgUgJgJQgIgJgVAAQgOAAgRAEIAACKIgdAAIAAibQAhgKAcAAQBCAAAAA6IAABrg");
	this.shape_40.setTransform(44.1,29.625);
	this.shape_40._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_40).wait(3).to({_off:false},0).wait(297));

	// a
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EC0000").s().p("AgwBAQgRgVAAgqQAAhVBMAAQAeAAAZAJIAACcIgaAAIgBgWQgPAagbAAQgdAAgQgVgAglAAQAAA+ApAAQAUAAAOgQIAAhnQgNgEgPAAQgvAAAAA9g");
	this.shape_41.setTransform(26.925,29.825);
	this.shape_41._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(2).to({_off:false},0).wait(298));

	// B
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EC0000").s().p("AhIBzIAAjgQAZgFAfAAQAoAAAUAQQAVAPAAAdQAAAkghAQQApAMAAAqQAAAegUARQgUAQgkAAgAgrBaIAnAAQAwAAAAgnQAAgngyAAIglAAgAgrhYIAABLIAjAAQArAAAAgmQABgmgzAAg");
	this.shape_42.setTransform(10.8,26.4);
	this.shape_42._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_42).wait(1).to({_off:false},0).wait(299));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,239.9,122.7);


(lib.mc_background = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EC0000").s().dr(-150,-300,300,600);
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_background, new cjs.Rectangle(0,0,300,600), null);


// stage content:
(lib._300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_299 = function() {
		if (!this.looped) this.looped = 1;
		if (this.looped++ == 2) this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(299).call(this.frame_299).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#EC0000").ss(2,1,1).p("EgXRgutMAujAAAMAAABdbMgujAAAg");
	this.shape.setTransform(150.0109,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(300));

	// logo_pos
	this.instance = new lib.SantanderInternationalpos();
	this.instance.parent = this;
	this.instance.setTransform(322.2,111.8,0.6667,0.6661,0,0,0,408.3,122.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(300));

	// primary_cta
	this.instance_1 = new lib.primary_cta();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,552.95,1,1,0,0,0,72,17);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.primary_cta(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(137).to({_off:false},0).to({alpha:1},30).wait(133));

	// header
	this.instance_2 = new lib.mc_level1_finalIOM();
	this.instance_2.parent = this;
	this.instance_2.setTransform(116.2,292,1,1,0,0,0,86.2,77);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(44).to({_off:false},0).wait(256));

	// subheader
	this.instance_3 = new lib.mc_level4_jersey();
	this.instance_3.parent = this;
	this.instance_3.setTransform(78.95,403.35,0.7196,0.7197,0,0,0,68,42.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(107).to({_off:false},0).to({alpha:1},30).wait(163));

	// background_colour
	this.instance_4 = new lib.mc_background();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({y:-300},29,cjs.Ease.quartInOut).wait(271));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,-300,150,900);
// library properties:
lib.properties = {
	id: '05920BE2A36F420086AAC3866015E257',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['05920BE2A36F420086AAC3866015E257'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;